/**
 * Internal support classes for the JUnit Jupiter test engine.
 */

package org.junit.jupiter.engine.support;
